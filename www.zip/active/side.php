
<?php
if (!empty($_SESSION['mmmorpglogin'])) {
   include 'style/user.html';      
	
} else {
	
	

	include 'style/login.html';		    
}

?>
