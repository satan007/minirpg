<?php
class usual
{    
    public static function hash_pass()
    {
      $pass_hash = md5($password)
    }}?>
